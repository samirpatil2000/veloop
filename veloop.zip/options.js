// extension/src/core/clip-store.ts
var DB_NAME = "VideoPedalDB";
var STORE_NAME = "clips";
var DB_VERSION = 1;
function openDB() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not supported in this environment"));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt", { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function getAllClips() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => {
      const clips = request.result || [];
      clips.sort((a, b) => b.createdAt - a.createdAt);
      resolve(clips);
    };
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => db.close();
  });
}

// extension/src/options/options.ts
var ids = [
  "maxRecordingSeconds",
  "minRecordingSeconds",
  "crossfadeSeconds",
  "overlayOpacity"
];
function bindRangeAndNumber(id) {
  const numInput = document.getElementById(id);
  const rangeInput = document.getElementById(`${id}_range`);
  if (numInput && rangeInput) {
    rangeInput.addEventListener("input", () => {
      numInput.value = rangeInput.value;
    });
    numInput.addEventListener("input", () => {
      rangeInput.value = numInput.value;
    });
  }
}
async function load() {
  for (const id of ids) {
    bindRangeAndNumber(id);
  }
  const result = await chrome.storage.local.get("settings");
  const settings = result.settings ?? {};
  for (const id of ids) {
    const numInput = document.getElementById(id);
    const rangeInput = document.getElementById(`${id}_range`);
    const val = settings[id] ?? (id === "maxRecordingSeconds" ? 30 : id === "minRecordingSeconds" ? 0.8 : id === "crossfadeSeconds" ? 0.5 : 0.5);
    if (numInput) numInput.value = String(val);
    if (rangeInput) rangeInput.value = String(val);
  }
  try {
    const clips = await getAllClips();
    const countEl = document.getElementById("presetsCount");
    if (countEl) countEl.textContent = String(clips.length);
  } catch {
  }
}
async function save() {
  const current = (await chrome.storage.local.get("settings")).settings ?? {};
  const next = { ...current };
  for (const id of ids) {
    const el = document.getElementById(id);
    if (el) {
      next[id] = Number(el.value);
    }
  }
  await chrome.storage.local.set({ settings: next });
  try {
    await chrome.runtime.sendMessage({
      type: "PEDAL_UPDATE_SETTINGS",
      payload: next
    });
  } catch {
  }
  const savedEl = document.getElementById("saved");
  if (savedEl) {
    savedEl.classList.add("visible");
    setTimeout(() => {
      savedEl.classList.remove("visible");
    }, 1800);
  }
}
document.getElementById("save")?.addEventListener("click", save);
void load();
