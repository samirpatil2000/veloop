// extension/src/content/bridge.ts
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.data?.source !== "video-pedal-page") return;
  try {
    if (!chrome?.runtime?.id) return;
    chrome.runtime.sendMessage({
      type: event.data.type,
      payload: event.data.payload
    }).catch(() => {
    });
  } catch {
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  window.postMessage(
    {
      source: "video-pedal-extension",
      type: message.type,
      payload: message.payload
    },
    "*"
  );
  if (message.type === "PEDAL_GET_STATE" || message.type === "PEDAL_TOGGLE_RECORD" || message.type === "PEDAL_GO_LIVE" || message.type === "PEDAL_START_RECORD" || message.type === "PEDAL_STOP_RECORD" || message.type === "PEDAL_PLAY_SAVED_CLIP") {
    const handler = (event) => {
      if (event.source !== window) return;
      if (event.data?.source !== "video-pedal-page") return;
      if (event.data?.type === "PEDAL_STATE_CHANGED") {
        window.removeEventListener("message", handler);
        sendResponse(event.data.payload);
      }
    };
    window.addEventListener("message", handler);
    setTimeout(() => {
      window.removeEventListener("message", handler);
      sendResponse({ state: null });
    }, 3e3);
    return true;
  }
  if (message.type === "PEDAL_EXPORT_CURRENT_LOOP") {
    const handler = (event) => {
      if (event.source !== window) return;
      if (event.data?.source !== "video-pedal-page") return;
      if (event.data?.type === "PEDAL_EXPORT_CURRENT_LOOP_RESULT") {
        window.removeEventListener("message", handler);
        sendResponse(event.data.payload);
      }
    };
    window.addEventListener("message", handler);
    setTimeout(() => {
      window.removeEventListener("message", handler);
      sendResponse(null);
    }, 4e3);
    return true;
  }
});
